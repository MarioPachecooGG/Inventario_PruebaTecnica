<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }

        h2 {
            text-align: center;
        }

        .total {
            font-weight: bold;
            background: #f2f2f2;
        }
    </style>
</head>

<body>

<h2>REPORTE MENSUAL DE VENTAS</h2>

<p><strong>Fecha de emisión:</strong> <?php echo e(now()); ?></p>

<table>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Unidades Vendidas</th>
            <th>Ingresos</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($row->product_name); ?></td>
            <td><?php echo e($row->total_units); ?></td>
            <td>$<?php echo e(number_format($row->total_income, 2)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <tr class="total">
            <td>TOTAL</td>
            <td><?php echo e($totalUnits); ?></td>
            <td>$<?php echo e(number_format($totalIncome, 2)); ?></td>
        </tr>
    </tbody>
</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\inventarioo\resources\views/reports/monthly.blade.php ENDPATH**/ ?>